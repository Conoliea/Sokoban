package Sokoban;

public class Wall extends MapElement{

	
	
}
