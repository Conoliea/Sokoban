package Sokoban;

public class Player {

}
