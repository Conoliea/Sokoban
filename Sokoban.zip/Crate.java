package Sokoban;

public class Crate {

}
