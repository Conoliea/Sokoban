package Sokoban;

public class Diamond {

}
