package Sokoban;

public class MapElement {

}
