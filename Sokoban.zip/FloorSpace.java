package Sokoban;

public class FloorSpace {

}
